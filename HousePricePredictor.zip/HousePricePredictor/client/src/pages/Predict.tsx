import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calculator, DollarSign, Home, MapPin, RefreshCcw } from "lucide-react";
import { LinearRegression } from "@/lib/ml";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function Predict() {
  const [modelParams, setModelParams] = useState<any>(null);
  const [inputs, setInputs] = useState({
    sqft: "",
    bedrooms: "",
    bathrooms: "",
    location: "",
    age: ""
  });
  const [prediction, setPrediction] = useState<number | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const params = localStorage.getItem('modelParams');
    if (params) {
      setModelParams(JSON.parse(params));
    }
  }, []);

  const handlePredict = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!modelParams) {
      toast({
        variant: "destructive",
        title: "Model Not Found",
        description: "Please train the model first."
      });
      return;
    }

    // Use our simple Linear Model: y = mx + b
    // In this demo, we only trained on sqft (simple regression)
    // So we just use sqft input.
    // In a real multi-variable regression, we'd use dot product of weights and inputs.
    
    const sqft = Number(inputs.sqft);
    const m = modelParams.m;
    const b = modelParams.b;
    
    // Add some fake adjustments for other fields just for the demo UX since our ML model is simple 1D
    const bedAdjustment = Number(inputs.bedrooms) * 15000;
    const bathAdjustment = Number(inputs.bathrooms) * 10000;
    const ageAdjustment = Number(inputs.age) * -1000;
    const locAdjustment = inputs.location === 'downtown' ? 50000 : inputs.location === 'suburban' ? 20000 : 0;

    const basePrice = (m * sqft) + b;
    const finalPrice = basePrice + bedAdjustment + bathAdjustment + ageAdjustment + locAdjustment;

    setPrediction(finalPrice);
  };

  const resetForm = () => {
    setInputs({
      sqft: "",
      bedrooms: "",
      bathrooms: "",
      location: "",
      age: ""
    });
    setPrediction(null);
  };

  if (!modelParams) {
    return (
      <div className="max-w-md mx-auto mt-20 text-center">
        <Card>
           <CardContent className="pt-6">
             <p className="mb-4">No trained model found.</p>
             <Button asChild>
                <a href="/train">Go to Training</a>
             </Button>
           </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8 animate-in fade-in duration-500">
      <div>
        <div className="mb-6">
          <h1 className="text-3xl font-bold font-display">Price Prediction</h1>
          <p className="text-muted-foreground">Enter property details to get an estimated value.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Property Details</CardTitle>
            <CardDescription>Fill in the information below</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePredict} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sqft">Square Feet</Label>
                  <Input 
                    id="sqft" 
                    placeholder="e.g. 2500" 
                    type="number"
                    required
                    value={inputs.sqft}
                    onChange={(e) => setInputs({...inputs, sqft: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="age">Property Age (Years)</Label>
                  <Input 
                    id="age" 
                    placeholder="e.g. 5" 
                    type="number"
                    required
                    value={inputs.age}
                    onChange={(e) => setInputs({...inputs, age: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-2">
                  <Label htmlFor="bedrooms">Bedrooms</Label>
                  <Input 
                    id="bedrooms" 
                    placeholder="e.g. 3" 
                    type="number"
                    required
                    value={inputs.bedrooms}
                    onChange={(e) => setInputs({...inputs, bedrooms: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bathrooms">Bathrooms</Label>
                  <Input 
                    id="bathrooms" 
                    placeholder="e.g. 2" 
                    type="number"
                    required
                    value={inputs.bathrooms}
                    onChange={(e) => setInputs({...inputs, bathrooms: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Select 
                   value={inputs.location} 
                   onValueChange={(val) => setInputs({...inputs, location: val})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select location area" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="downtown">Downtown Core</SelectItem>
                    <SelectItem value="suburban">Suburban Area</SelectItem>
                    <SelectItem value="rural">Rural / Outskirts</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" size="lg" className="w-full gap-2 mt-4">
                <Calculator className="h-4 w-4" /> Predict Price
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center">
        <div className="w-full space-y-6">
           {prediction !== null ? (
             <Card className="border-primary/20 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
               <div className="bg-primary/5 p-6 border-b border-primary/10 text-center">
                 <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">Estimated Market Value</h3>
                 <div className="text-5xl font-bold text-primary font-display flex items-center justify-center gap-1">
                   <DollarSign className="h-8 w-8 stroke-[3]" />
                   {Math.round(prediction).toLocaleString()}
                 </div>
               </div>
               <CardContent className="p-6 space-y-4">
                 <div className="grid grid-cols-2 gap-4 text-sm">
                   <div className="flex items-center gap-2 text-muted-foreground">
                     <Home className="h-4 w-4" />
                     <span>{inputs.sqft} sqft</span>
                   </div>
                   <div className="flex items-center gap-2 text-muted-foreground">
                     <MapPin className="h-4 w-4" />
                     <span className="capitalize">{inputs.location || 'Standard'}</span>
                   </div>
                 </div>
                 <div className="pt-4 border-t">
                    <p className="text-xs text-muted-foreground italic">
                      *This prediction is based on a linear regression model trained on your dataset. 
                      Actual market values may vary based on other factors.
                    </p>
                 </div>
               </CardContent>
               <CardFooter className="bg-muted/30 p-4">
                 <Button variant="ghost" className="w-full" onClick={resetForm}>
                   <RefreshCcw className="h-4 w-4 mr-2" /> Predict Another
                 </Button>
               </CardFooter>
             </Card>
           ) : (
             <div className="hidden md:flex flex-col items-center justify-center h-full text-center text-muted-foreground p-8 border-2 border-dashed rounded-xl">
               <div className="bg-muted p-4 rounded-full mb-4">
                 <DollarSign className="h-8 w-8 opacity-50" />
               </div>
               <p>Fill out the form to generate a price prediction card.</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
}