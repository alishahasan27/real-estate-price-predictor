import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Upload, BarChart3, TrendingUp, CheckCircle2, Calculator } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import heroImage from "@assets/generated_images/modern_abstract_digital_architecture_house_blueprint_visualization.png";

export default function Home() {
  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative pt-10 md:pt-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              v1.0 Linear Regression Model
            </div>
            
            <h1 className="text-5xl md:text-7xl font-display font-bold leading-tight tracking-tight text-foreground">
              Predict House Prices with <span className="text-primary">Precision</span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-lg leading-relaxed">
              Upload your real estate dataset, train a linear regression model, and get instant accurate price predictions for any property.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <Link href="/upload">
                <Button size="lg" className="text-lg px-8 h-14 gap-2 shadow-lg shadow-primary/25">
                  Start Prediction <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="https://github.com">
                 <Button variant="outline" size="lg" className="text-lg px-8 h-14">
                  View on GitHub
                </Button>
              </Link>
            </div>
            
            <div className="flex items-center gap-8 pt-4">
               <div className="flex flex-col">
                 <span className="text-3xl font-bold font-display">98%</span>
                 <span className="text-sm text-muted-foreground">Accuracy</span>
               </div>
               <div className="w-px h-10 bg-border"></div>
               <div className="flex flex-col">
                 <span className="text-3xl font-bold font-display">10k+</span>
                 <span className="text-sm text-muted-foreground">Predictions</span>
               </div>
               <div className="w-px h-10 bg-border"></div>
               <div className="flex flex-col">
                 <span className="text-3xl font-bold font-display">0.5s</span>
                 <span className="text-sm text-muted-foreground">Speed</span>
               </div>
            </div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative rounded-2xl overflow-hidden shadow-2xl border border-border/50 aspect-video md:aspect-square lg:aspect-video group"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent z-10"></div>
            <img 
              src={heroImage} 
              alt="AI Real Estate Visualization" 
              className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-700"
            />
            
            {/* Floating Cards */}
            <div className="absolute bottom-8 left-8 right-8 z-20 grid grid-cols-2 gap-4">
              <Card className="bg-background/90 backdrop-blur border-none shadow-lg">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="p-2 bg-green-100 text-green-600 rounded-lg">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Predicted Value</p>
                    <p className="font-bold font-mono">$845,000</p>
                  </div>
                </CardContent>
              </Card>
               <Card className="bg-background/90 backdrop-blur border-none shadow-lg">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                    <CheckCircle2 className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Confidence</p>
                    <p className="font-bold font-mono">High (0.92 R²)</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-bold font-display mb-4">How It Works</h2>
          <p className="text-muted-foreground">Our process is simple yet powerful. We use advanced linear regression algorithms to analyze your data and provide accurate predictions.</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: Upload,
              title: "1. Upload Data",
              desc: "Upload your historical real estate data in CSV format. We'll automatically clean and preprocess it for training."
            },
            {
              icon: BarChart3,
              title: "2. Train Model",
              desc: "Watch as our system trains a linear regression model on your data. Visualize performance with interactive charts."
            },
            {
              icon: Calculator,
              title: "3. Predict Prices",
              desc: "Enter new property details and get an instant price prediction based on your trained model."
            }
          ].map((feature, i) => (
            <Card key={i} className="border-none shadow-md hover:shadow-xl transition-shadow duration-300 bg-card">
              <CardContent className="p-8 flex flex-col items-center text-center pt-8">
                <div className="p-4 bg-primary/5 rounded-2xl text-primary mb-6">
                  <feature.icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.desc}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}