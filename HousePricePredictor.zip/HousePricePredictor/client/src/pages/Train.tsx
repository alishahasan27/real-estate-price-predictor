import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { ArrowRight, Play, CheckCircle, AlertTriangle } from "lucide-react";
import { LinearRegression } from "@/lib/ml";
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Line, ComposedChart } from 'recharts';
import { useToast } from "@/hooks/use-toast";

export default function Train() {
  const [training, setTraining] = useState(false);
  const [complete, setComplete] = useState(false);
  const [metrics, setMetrics] = useState<any>(null);
  const [plotData, setPlotData] = useState<any[]>([]);
  const [data, setData] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    const storedData = localStorage.getItem('housingData');
    if (storedData) {
      setData(JSON.parse(storedData));
    }
  }, []);

  const handleTrain = () => {
    if (data.length === 0) {
      toast({
        variant: "destructive",
        title: "No Data Found",
        description: "Please upload a dataset first."
      });
      return;
    }

    setTraining(true);

    // Simulate training delay for effect
    setTimeout(() => {
      try {
        // Assume 'sqft' is feature and 'price' is target for this demo
        // In a real app, we'd let user select columns
        const featureKey = Object.keys(data[0]).find(k => k.toLowerCase().includes('sqft') || k.toLowerCase().includes('area')) || Object.keys(data[0])[1];
        const targetKey = Object.keys(data[0]).find(k => k.toLowerCase().includes('price')) || Object.keys(data[0])[data[0].length-1];

        const x = data.map(row => Number(row[featureKey]));
        const y = data.map(row => Number(row[targetKey]));

        const model = new LinearRegression();
        model.fit(x, y);

        const r2 = model.score(x, y);
        const mae = model.mae(x, y);
        const mse = model.mse(x, y);
        const { m, b } = model.getCoefficients();

        // Prepare plot data: Actual vs Predicted Line
        // Generate points for the line
        const minX = Math.min(...x);
        const maxX = Math.max(...x);
        
        const plotPoints = data.map((row, i) => ({
          x: x[i],
          y: y[i],
          yPred: model.predict(x[i])
        })).slice(0, 200); // Limit points for performance

        // Save model to localStorage for prediction page
        localStorage.setItem('modelParams', JSON.stringify({ m, b, featureKey, targetKey }));

        setMetrics({ r2, mae, mse });
        setPlotData(plotPoints);
        setComplete(true);
        setTraining(false);

        toast({
          title: "Training Complete",
          description: `Model trained successfully with R²: ${r2.toFixed(4)}`
        });

      } catch (e) {
        console.error(e);
        setTraining(false);
        toast({
          variant: "destructive",
          title: "Training Error",
          description: "Could not train model on this data."
        });
      }
    }, 1500);
  };

  if (data.length === 0) {
     return (
       <div className="flex flex-col items-center justify-center h-[60vh] text-center space-y-4">
         <AlertTriangle className="h-16 w-16 text-yellow-500/50" />
         <h2 className="text-2xl font-bold">No Dataset Found</h2>
         <p className="text-muted-foreground">Please upload a CSV dataset to begin training.</p>
         <Link href="/upload">
           <Button>Go to Upload</Button>
         </Link>
       </div>
     )
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold font-display">Model Training</h1>
          <p className="text-muted-foreground">Train a Linear Regression model on your dataset.</p>
        </div>
        {!complete && (
          <Button size="lg" onClick={handleTrain} disabled={training} className="gap-2">
            {training ? (
              <>Training...</>
            ) : (
              <>
                <Play className="h-4 w-4" /> Train Model
              </>
            )}
          </Button>
        )}
        {complete && (
          <Link href="/predict">
            <Button size="lg" className="gap-2 bg-green-600 hover:bg-green-700 text-white">
              Go to Prediction <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        )}
      </div>

      {complete && metrics && (
        <div className="grid gap-4 md:grid-cols-3 animate-in slide-in-from-bottom-4 duration-700">
          <Card className="border-l-4 border-l-primary">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">R² Score (Accuracy)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold font-mono">{metrics.r2.toFixed(4)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {metrics.r2 > 0.7 ? "High correlation" : "Moderate correlation"}
              </p>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-accent">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Mean Absolute Error</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold font-mono text-accent">${Math.round(metrics.mae).toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">Average error per prediction</p>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-orange-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Mean Squared Error</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold font-mono text-orange-600">{(metrics.mse / 1000000).toFixed(2)}M</div>
              <p className="text-xs text-muted-foreground mt-1">Penalizes large errors</p>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid gap-8 md:grid-cols-2">
         {/* Actual vs Predicted Graph */}
         <Card className="md:col-span-2 h-[500px] flex flex-col">
            <CardHeader>
              <CardTitle>Regression Fit: Price vs Square Feet</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 min-h-0">
              {plotData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={plotData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="x" 
                      type="number" 
                      label={{ value: 'Square Feet', position: 'insideBottomRight', offset: -10 }} 
                      domain={['auto', 'auto']}
                    />
                    <YAxis 
                      label={{ value: 'Price ($)', angle: -90, position: 'insideLeft' }} 
                      tickFormatter={(value) => `$${value/1000}k`}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                      formatter={(value: number) => [`$${Math.round(value).toLocaleString()}`, 'Price']}
                    />
                    <Scatter name="Actual Data" dataKey="y" fill="hsl(var(--primary))" opacity={0.6} />
                    <Line type="monotone" dataKey="yPred" stroke="hsl(var(--accent))" strokeWidth={3} dot={false} name="Regression Line" />
                  </ComposedChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center bg-muted/20 rounded-lg border-2 border-dashed">
                  <p className="text-muted-foreground">Train model to view visualization</p>
                </div>
              )}
            </CardContent>
         </Card>
      </div>
    </div>
  );
}