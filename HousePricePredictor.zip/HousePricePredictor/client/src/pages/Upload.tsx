import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Upload as UploadIcon, FileSpreadsheet, AlertCircle, Check, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import Papa from "papaparse";
import { generateMockData } from "@/lib/ml";

export default function Upload() {
  const [data, setData] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const processData = (results: any[]) => {
    // Basic cleaning: remove rows with null values
    const cleanData = results.filter(row => Object.values(row).every(val => val !== null && val !== ""));
    
    setData(cleanData);
    
    // Calculate summary stats for 'price' if it exists, or just the first numeric column
    const numericKeys = Object.keys(cleanData[0]).filter(key => !isNaN(Number(cleanData[0][key])));
    
    if (numericKeys.length > 0) {
      const targetKey = numericKeys.includes('price') ? 'price' : numericKeys[numericKeys.length - 1];
      const values = cleanData.map(row => Number(row[targetKey]));
      const sum = values.reduce((a, b) => a + b, 0);
      const mean = sum / values.length;
      const sorted = [...values].sort((a, b) => a - b);
      const median = sorted[Math.floor(sorted.length / 2)];
      
      setStats({
        count: cleanData.length,
        mean: mean.toFixed(2),
        median: median.toFixed(2),
        targetColumn: targetKey
      });
    }

    // Store in localStorage for the Train page to pick up
    localStorage.setItem('housingData', JSON.stringify(cleanData));
    
    toast({
      title: "Dataset Processed",
      description: `Successfully loaded ${cleanData.length} rows.`,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      complete: (results) => {
        processData(results.data);
      },
      error: (error) => {
        toast({
          variant: "destructive",
          title: "Error parsing CSV",
          description: error.message
        });
      }
    });
  };

  const loadSampleData = () => {
    const mock = generateMockData(500);
    processData(mock);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display">Upload Dataset</h1>
          <p className="text-muted-foreground">Upload your CSV file to begin the training process.</p>
        </div>
        <div className="flex gap-3">
           <Button variant="outline" onClick={loadSampleData}>
             Use Sample Data
           </Button>
        </div>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        {/* Upload Area */}
        <Card className="md:col-span-1 border-dashed border-2 hover:border-primary/50 transition-colors">
          <CardContent className="flex flex-col items-center justify-center h-64 text-center p-6">
            <div className="p-4 bg-primary/10 rounded-full mb-4">
              <UploadIcon className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Drop CSV file here</h3>
            <p className="text-sm text-muted-foreground mb-6">or click to browse</p>
            <input 
              type="file" 
              accept=".csv" 
              className="hidden" 
              ref={fileInputRef}
              onChange={handleFileUpload}
            />
            <Button onClick={() => fileInputRef.current?.click()}>
              Select File
            </Button>
          </CardContent>
        </Card>

        {/* Stats Area */}
        <Card className="md:col-span-2">
          <CardHeader>
             <CardTitle className="flex items-center gap-2">
               <FileSpreadsheet className="h-5 w-5 text-primary" />
               Dataset Summary
             </CardTitle>
          </CardHeader>
          <CardContent>
            {stats ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground uppercase font-semibold">Rows</p>
                  <p className="text-2xl font-mono font-bold">{stats.count}</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground uppercase font-semibold">Target</p>
                  <p className="text-2xl font-mono font-bold capitalize text-primary truncate">{stats.targetColumn}</p>
                </div>
                 <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground uppercase font-semibold">Mean Price</p>
                  <p className="text-2xl font-mono font-bold truncate">${Number(stats.mean).toLocaleString()}</p>
                </div>
                 <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground uppercase font-semibold">Median Price</p>
                  <p className="text-2xl font-mono font-bold truncate">${Number(stats.median).toLocaleString()}</p>
                </div>
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground flex-col gap-2">
                <AlertCircle className="h-8 w-8 opacity-20" />
                <p>No data loaded yet</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Data Preview */}
      {data.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Data Preview (First 10 Rows)</CardTitle>
            <Link href="/train">
              <Button className="gap-2">
                Proceed to Training <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader className="bg-muted/50">
                  <TableRow>
                    {Object.keys(data[0]).map((header) => (
                      <TableHead key={header} className="capitalize font-bold text-foreground">{header}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.slice(0, 10).map((row, i) => (
                    <TableRow key={i}>
                      {Object.values(row).map((val: any, j) => (
                        <TableCell key={j} className="font-mono text-sm">
                          {typeof val === 'number' ? val.toLocaleString() : val}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}