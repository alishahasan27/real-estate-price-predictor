
/**
 * A simple Linear Regression implementation in TypeScript
 * Supports single variable regression for this demo
 * y = mx + b
 */

export class LinearRegression {
  private m: number = 0;
  private b: number = 0;
  private trained: boolean = false;

  constructor() {}

  fit(x: number[], y: number[]) {
    if (x.length !== y.length) {
      throw new Error("Input vectors must be of same length");
    }

    const n = x.length;
    
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((a, b, i) => a + b * y[i], 0);
    const sumXX = x.reduce((a, b) => a + b * b, 0);

    // Calculate slope (m) and intercept (b)
    this.m = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    this.b = (sumY - this.m * sumX) / n;
    
    this.trained = true;
  }

  predict(x: number): number {
    if (!this.trained) throw new Error("Model not trained");
    return this.m * x + this.b;
  }

  getCoefficients() {
    return { m: this.m, b: this.b };
  }

  // Metrics
  
  // R-squared
  score(x: number[], y: number[]): number {
    const yPred = x.map(val => this.predict(val));
    const yMean = y.reduce((a, b) => a + b, 0) / y.length;
    
    const ssRes = y.reduce((a, b, i) => a + Math.pow(b - yPred[i], 2), 0);
    const ssTot = y.reduce((a, b) => a + Math.pow(b - yMean, 2), 0);
    
    return 1 - (ssRes / ssTot);
  }

  mae(x: number[], y: number[]): number {
    const yPred = x.map(val => this.predict(val));
    return y.reduce((a, b, i) => a + Math.abs(b - yPred[i]), 0) / y.length;
  }

  mse(x: number[], y: number[]): number {
    const yPred = x.map(val => this.predict(val));
    return y.reduce((a, b, i) => a + Math.pow(b - yPred[i], 2), 0) / y.length;
  }
}

// Mock Data Generator for fallback
export const generateMockData = (count: number = 100) => {
  const data = [];
  for (let i = 0; i < count; i++) {
    // Sqft between 800 and 5000
    const sqft = Math.floor(Math.random() * (5000 - 800 + 1)) + 800;
    // Bedrooms 1-6
    const bedrooms = Math.floor(Math.random() * 6) + 1;
    // Age 0-50
    const age = Math.floor(Math.random() * 50);
    
    // Base price calculation with some noise
    // $300 per sqft base + noise
    let price = (sqft * 300) + (bedrooms * 25000) - (age * 2000) + (Math.random() * 50000 - 25000);
    
    // Ensure positive price
    price = Math.max(100000, price);

    data.push({
      id: i,
      sqft,
      bedrooms,
      bathrooms: Math.floor(bedrooms * 0.75) + 1,
      age,
      location: ['Downtown', 'Suburban', 'Rural'][Math.floor(Math.random() * 3)],
      price: Math.round(price)
    });
  }
  return data;
};
