import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import pickle
import os

# Configuration
MODEL_FILE = 'model.pkl'

def load_and_preprocess_data(file_path):
    """
    Loads data, cleans it, and prepares features/target.
    Assumes 'price' is the target column.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    # Load dataset
    df = pd.read_csv(file_path)
    print(f"Dataset loaded. Shape: {df.shape}")
    
    # Data Cleaning: Drop rows with missing target
    if 'price' not in df.columns:
        raise ValueError("Dataset must contain a 'price' column")
        
    df = df.dropna(subset=['price'])
    
    # Fill missing values for numerical columns with median
    numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns
    for col in numerical_cols:
        df[col] = df[col].fillna(df[col].median())
        
    # Fill missing values for categorical columns with mode
    categorical_cols = df.select_dtypes(include=['object']).columns
    for col in categorical_cols:
        df[col] = df[col].fillna(df[col].mode()[0])
        
    # Separate Features and Target
    X = df.drop('price', axis=1)
    y = df['price']
    
    return X, y, categorical_cols, numerical_cols

def train_model(file_path):
    """
    Full training pipeline: Load -> Split -> Train -> Evaluate -> Save
    """
    print("--- Starting Model Training ---")
    
    # 1. Load Data
    try:
        X, y, cat_cols, num_cols = load_and_preprocess_data(file_path)
    except Exception as e:
        print(f"Error loading data: {e}")
        return
    
    # 2. Preprocessing Pipeline (Encoding categorical data)
    # numerical features are passed through, categorical are one-hot encoded
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', 'passthrough', [c for c in num_cols if c != 'price']),
            ('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols)
        ])
    
    # 3. Create Pipeline with Linear Regression
    model = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', LinearRegression())
    ])
    
    # 4. Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # 5. Train Model
    print("Training Linear Regression model...")
    model.fit(X_train, y_train)
    
    # 6. Make Predictions on Test Set
    y_pred = model.predict(X_test)
    
    # 7. Accuracy Metrics
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    
    print("\n--- Model Performance ---")
    print(f"MAE: {mae:.2f}")
    print(f"MSE: {mse:.2f}")
    print(f"RMSE: {rmse:.2f}")
    print(f"R² Score: {r2:.4f}")
    
    # 8. Plots
    plt.figure(figsize=(12, 5))
    
    # Plot 1: Actual vs Predicted
    plt.subplot(1, 2, 1)
    plt.scatter(y_test, y_pred, alpha=0.5)
    plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--', lw=2)
    plt.xlabel('Actual Price')
    plt.ylabel('Predicted Price')
    plt.title('Actual vs Predicted Prices')
    
    # Plot 2: Distribution of Prices
    plt.subplot(1, 2, 2)
    plt.hist(y, bins=30, color='skyblue', edgecolor='black')
    plt.xlabel('Price')
    plt.ylabel('Frequency')
    plt.title('Distribution of House Prices')
    
    plt.tight_layout()
    plt.savefig('model_plots.png')
    print("\nPlots saved to 'model_plots.png'")
    
    # 9. Save Model
    with open(MODEL_FILE, 'wb') as f:
        pickle.dump(model, f)
    print(f"Model saved to '{MODEL_FILE}'")
    
    return model

def predict_price(features_dict):
    """
    Predicts price for a single sample using the saved model.
    """
    if not os.path.exists(MODEL_FILE):
        print("Model file not found. Please train the model first.")
        return None
        
    with open(MODEL_FILE, 'rb') as f:
        model = pickle.load(f)
        
    # Convert dict to DataFrame
    input_df = pd.DataFrame([features_dict])
    
    try:
        prediction = model.predict(input_df)[0]
        return prediction
    except Exception as e:
        print(f"Prediction error: {e}")
        return None

if __name__ == "__main__":
    # Example Usage
    
    # Generate dummy data for demonstration if file doesn't exist
    dummy_csv = 'housing_data.csv'
    if not os.path.exists(dummy_csv):
        print(f"Generating dummy data to '{dummy_csv}'...")
        data = {
            'sqft': np.random.randint(800, 5000, 100),
            'bedrooms': np.random.randint(1, 6, 100),
            'location': np.random.choice(['Downtown', 'Suburb', 'Rural'], 100),
            'age': np.random.randint(0, 50, 100)
        }
        df = pd.DataFrame(data)
        # Generate price based on features + noise
        df['price'] = (df['sqft'] * 300) + (df['bedrooms'] * 20000) - (df['age'] * 1000) + np.random.randint(-20000, 20000, 100)
        df.to_csv(dummy_csv, index=False)
    
    # Train
    train_model(dummy_csv)
    
    # Predict
    print("\n--- Sample Prediction ---")
    sample_house = {
        'sqft': 2500,
        'bedrooms': 3,
        'location': 'Suburb',
        'age': 10
    }
    price = predict_price(sample_house)
    
    if price:
        print(f"Input Features: {sample_house}")
        print(f"Predicted Price: ${price:,.2f}")
